"""Send fake traffic to the API so the Grafana dashboard has something to show.

Usage:
    python scripts/generate_traffic.py                          # 120 requests to localhost:8000
    python scripts/generate_traffic.py http://localhost:8000 300
Uses only the Python standard library (no pip install needed).
"""
import json
import random
import sys
import time
import urllib.error
import urllib.request

base = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000"
total = int(sys.argv[2]) if len(sys.argv) > 2 else 120


def post(payload):
    req = urllib.request.Request(
        f"{base}/predict",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
    )
    try:
        return urllib.request.urlopen(req, timeout=5).status
    except urllib.error.HTTPError as e:
        return e.code


for i in range(total):
    if i % 15 == 14:  # every 15th request is deliberately bad -> shows up in the error panel
        payload = {"present_price": "oops"}
    else:
        payload = {
            "present_price": round(random.uniform(2, 20), 2),
            "kms_driven": random.randint(1000, 120000),
            "fuel_type": random.choice(["petrol", "diesel", "cng"]),
            "seller_type": random.choice(["dealer", "individual"]),
            "transmission": random.choice(["manual", "automatic"]),
            "owner": random.choice([0, 0, 0, 1, 2]),
            "year": random.randint(2008, 2024),
        }
    status = post(payload)
    print(f"{i + 1:>4}/{total}  HTTP {status}")
    time.sleep(random.uniform(0.05, 0.3))
print("Done. Open Grafana and set the time range to 'Last 5 minutes'.")
