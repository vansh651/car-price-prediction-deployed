import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import app  # noqa: E402


@pytest.fixture()
def client():
    app.config["TESTING"] = True
    return app.test_client()


def test_health_ok(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.get_json()["model_loaded"] is True


def test_home_page(client):
    assert client.get("/").status_code == 200


def test_predict_json(client):
    r = client.post(
        "/predict",
        json={
            "present_price": 5.5,
            "kms_driven": 30000,
            "fuel_type": "petrol",
            "seller_type": "dealer",
            "transmission": "manual",
            "owner": 0,
            "year": 2018,
        },
    )
    assert r.status_code == 200
    body = r.get_json()
    assert body["success"] is True
    assert body["predicted_price"] > 0


def test_predict_bad_input_returns_400(client):
    r = client.post("/predict", json={"present_price": "not-a-number"})
    assert r.status_code == 400
    assert r.get_json()["success"] is False


def test_metrics_exposed(client):
    client.post("/predict", json={"present_price": 5, "kms_driven": 1000, "year": 2020})
    text = client.get("/metrics").get_data(as_text=True)
    for name in (
        "http_requests_total",
        "http_request_duration_seconds",
        "predictions_total",
        "model_loaded 1.0",
    ):
        assert name in text
